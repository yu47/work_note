#ifndef PROC_H
#define PROC_H

#include <utmpx.h>
#include <linux/limits.h>

struct hide_pid{
    pid_t pid;
};

#endif