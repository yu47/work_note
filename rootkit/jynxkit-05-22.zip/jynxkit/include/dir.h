#ifndef DIT_H
#define	DIT_H

#define PATH_MAX 4096 


int is_name_invisible(const char *filename);
int add_hide_file_paths(char *hide_file_paths_str);
int delete_hide_file_paths();
int is_name_invisible2(const char *filename);


#endif