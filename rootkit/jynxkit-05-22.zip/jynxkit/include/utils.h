#ifndef UTILS_H
#define UTILS_H

// #include <stdio.h>
// #include <stdlib.h>
#include <string.h>
// #include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <netinet/in.h>

#define DATA_STZE 1024*1024

#define SHM_NAME "/shm_name"

#define MAX_FILENAME_LEN 2048

struct file_data {
    char filename[MAX_FILENAME_LEN];
};

struct proc_data {
    pid_t pid;
};

struct conn_data {
    struct sockaddr_in addr;
};

enum data_type {
    PROC_DATA,
    CONN_DATA
};

struct data {
    enum data_type type;
    union {
        struct proc_data proc;
        struct conn_data conn;
    } payload;
};

void update_file(char *hide_file_paths);
void add_proc(int pid);
void del_proc(int pid);
int search(int pid , struct sockaddr_in hide_addr);
void add_addr(struct sockaddr_in hide_addr);
void del_addr(struct sockaddr_in hide_addr);
int create_content();
void printf_all();
int delete_content();


#endif